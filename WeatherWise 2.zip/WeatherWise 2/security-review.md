# Privacy and security review
This is a source-level assessment, not a penetration-test result. Android’s security guidance informed the review.

Only INTERNET and ACCESS_NETWORK_STATE are explicitly requested; WorkManager can merge its normal scheduling permissions. There is no GPS, account, advertising or analytics. Search text and selected coordinates reach Open-Meteo, which also receives network metadata. The Places screen explains this processing.

HTTPS uses platform certificate validation; cleartext and redirects are disabled. Query text is length-limited and URL-encoded. Room uses bound queries in private app storage. Removing a place cascades to its cache. Backup is disabled, but manufacturer-specific transfer behaviour still needs testing.

The database is not independently encrypted; saved towns can reveal interests to someone controlling an unlocked/compromised device. Production work should assess encryption against the threat model, audit merged manifests/dependencies, test deletion and device transfer, and publish a privacy policy/Data Safety declaration. Release signing, abuse/rate-limit testing and accessibility checks remain outstanding. No secrets are embedded. Open-Meteo’s free endpoint has non-commercial usage restrictions; review licensing before release.

## Reference
Android Developers (2026), [Improve your app’s security](https://developer.android.com/privacy-and-security/security-best-practices), accessed 3 November 2026.
