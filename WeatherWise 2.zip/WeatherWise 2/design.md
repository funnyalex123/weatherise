# App description and design
Developer: [Your name], [Your ID]. WeatherWise helps users choose convenient outdoor activity times.

- MUST: informative, interactive Compose UI; state retained across rotation.
- SHOULD: hourly LazyColumn, ViewModel/StateFlow, three destinations, internet forecasts, loading/empty/error feedback.
- COULD: Room caching and WorkManager synchronisation; responsive Today layout.

## View layer
See `docs/wireframes.svg` for conceptual portrait/landscape layouts; replace or supplement with tested screenshots. Material 3 cards, buttons, text fields, chips and switches provide labelled controls. Today shows the current hourly forecast and upcoming hours; Plan compares activities; Places searches and manages saved towns. WeatherHero, HourCard and PlaceCard receive data/callbacks without owning business state. The activity ViewModel hoists domain state; rememberSaveable retains planner filters. At 700dp, Today’s hero and planning card share a row; narrower layouts stack. Lists scroll in both orientations.

## Architecture
WeatherViewModel exposes WeatherState, SearchState, saved places and notices through StateFlow. WeatherState holds place, forecast, download timestamp, loading and error. SavedStateHandle retains selected place ID and query; Room retains data across launches. Configuration changes retain the ViewModel. Lifecycle-aware collection controls UI observation.

Selecting a town emits an event, validates the saved-place limit, persists the place and refreshes its forecast through WeatherRepository. Room emits cache changes; the ViewModel parses them and updates state; Compose redraws. Superseded selection/search jobs are cancelled. WorkManager refreshes saved places approximately every six hours when connected; timing is system-controlled.

Room Place stores id:Long (primary key), name/region/country/zone:String and latitude/longitude:Double. CachedForecast stores placeId:Long (primary/foreign key, cascading deletion), json:String and updated:Long. Open-Meteo returns timezone plus hourly arrays: time, temperature_2m, precipitation_probability, wind_speed_10m, weather_code and is_day. Epoch seconds are displayed in the destination’s zone. Missing values cannot generate favourable recommendations.

## Navigation and resilience
Routes `today`, `plan`, `places` share one activity-scoped ViewModel; selected IDs are persisted rather than serialising forecasts into routes. Network/database exceptions become visible errors; cached data remains during failed refreshes. Forecasts older than six hours carry a warning. Empty and expired forecasts offer refresh. Worker retries are bounded. Activity thresholds are explicit convenience rules, not safety predictions.
