# Tool review — draft
The project uses Kotlin, Compose/Material 3, Room, WorkManager, Navigation and Gradle. Android Studio should provide emulator, Layout Inspector and Logcat evidence; no personal experience of running these tools is claimed here. GitHub Actions is configured but has not run.

ChatGPT generated and reviewed code from the assessment brief and the request for a weather app. Prompts focused on offline forecasts, transparent activity rules and error handling. The user selected the weather concept; architecture and numeric thresholds are AI proposals requiring review.

Complete this reflection after implementation: compare actual design/debugging/testing tools, cite reused code at its use, document key prompts, and describe at least two real AI mistakes you diagnosed and corrected. Do not present hypothetical failures as experience. Record your own design decisions and lessons. The initial AI review identified accessibility and background-refresh edge cases for further testing; passing checks must be evidenced.
